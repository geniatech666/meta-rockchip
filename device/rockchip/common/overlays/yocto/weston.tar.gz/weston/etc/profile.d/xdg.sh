#!/bin/sh
export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/run/user/0}
